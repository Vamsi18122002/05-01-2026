import { useEffect, useState } from "react";

function Users() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then(res => res.json())
      .then(data => setUsers(data));
  }, []);

  return (
    <ol>
      {users.map(user => (
        <li key={user.id}>{user.name}</li>
      ))}
    </ol>
  );}

  export default Users;