import { createStore } from "redux";

const initialState = {
  count: 0,
};

function reducer(state = initialState, action) {
  switch (action.type) {
    case "Increment":
      return {
        ...state,
        count: state.count + action.payload,
      };

    case "Decrement":
      return {
        ...state,
        count: state.count - action.payload,
      };

    default:
      return state;
  }
}

export const store = createStore(reducer);